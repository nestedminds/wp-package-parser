<?php
/**
 * Plugin Name: Test Plugin
 * Plugin URI: https://testplugin.com
 * Description: A parser test plugin.
 * Author: Capevace
 * Author URI: https://github.com/Capevace
 * Version: 1.5.1
 * Requires PHP: 7.2
 * Tested up to: 4.9
 * Requires at least: 3.8
 * Text Domain: test-plugin-domain
 *
 * Copyright: (c) 2018 Capevace
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * 
 * WC requires at least: 2.2.0
 * WC tested up to: 3.3.3
 *
 * @package   test-plugin
 * @author    Capevace
 * @category  Plugin
 * @copyright Copyright (c) 2018 Capevace
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */


/**
 * 
 * PLUGIN CODE HERE
 * 
 */